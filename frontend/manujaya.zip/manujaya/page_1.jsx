import React from 'react'
//import Carousel from './Components/Carousal';
//import Form from './Components/Form';
//import './page_1.css'; // Adjust the relative path if needed

const page_1 = () => {
  return (
    <div>
      
    </div>
  );
}

export default page_1
